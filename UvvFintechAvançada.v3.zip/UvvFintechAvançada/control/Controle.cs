﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.control
{
    internal class Controle
    {
        private Banco banco;
        public Controle()
        {
            banco = new Banco();
        }
        public bool AdicionarCliente(string nome, string cpf, string endereco)
        {
            return banco.gerenciadorDeClientes.AdicionarCliente(nome, cpf, endereco);
        }

        public bool RemoverCliente(string cpf)
        {
            return banco.gerenciadorDeClientes.RemoverCliente(cpf);
        }

        public Cliente? ConsultarCliente(string cpf)
        {
            return banco.gerenciadorDeClientes.ConsultarCliente(cpf);
        }

        public bool AdicionarConta(string cpf, string idConta, decimal saldo, string tipo)
        {
            return banco.gerenciadorDeContas.AdicionarConta(cpf, idConta, saldo, tipo);
        }

        public bool RemoverConta(string id)
        {
            return banco.gerenciadorDeContas.RemoverConta(id);
        }


        public Conta? ConsultarConta(string id)
        {
            return banco.gerenciadorDeContas.ConsultarConta(id);
        }

        public bool Depositar (string contaId, decimal valor)
        {
            return banco.gerenciadorDeTransacoes.Depositar(contaId, valor);
        }

        public int Sacar(string contaId, decimal valor)
        {
            return banco.gerenciadorDeTransacoes.Sacar(contaId, valor);
        }

        public int Transferir(string contaOrigemId, string contaDestinoId, decimal valor)
        {
            return banco.gerenciadorDeTransacoes.Transferir(contaOrigemId, contaDestinoId, valor);
        }
    }
}
