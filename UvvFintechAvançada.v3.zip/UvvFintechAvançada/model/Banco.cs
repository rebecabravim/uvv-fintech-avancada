﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace UvvFintechAvançada.model
{
    class Banco
    {

        private Calendario calendario;
        public GerenciadorDeContas gerenciadorDeContas;
        public GerenciadorDeClientes gerenciadorDeClientes;
        public GerenciadorDeTransacoes gerenciadorDeTransacoes;
        private static System.Timers.Timer timer;
        

        public Banco()
        {
            calendario = new Calendario();
            gerenciadorDeContas = new GerenciadorDeContas();
            gerenciadorDeClientes = new GerenciadorDeClientes();
            gerenciadorDeTransacoes = new GerenciadorDeTransacoes();


            timer = new System.Timers.Timer(15000);
            timer.Elapsed += atualizar; // Evento que será chamado a cada 15 segundos
            timer.AutoReset = true; // Faz o timer repetir
            timer.Enabled = true;

        }

        private void atualizar(Object source, ElapsedEventArgs e)
        {
            calendario.Avancar(); // Chama o método para avançar o calendário
            gerenciadorDeContas.AtualizarContasPoupanca(calendario.DataAtual);
        }
    }
}
