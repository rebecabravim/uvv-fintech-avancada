﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UvvFintechAvançada.model
{
    internal class Calendario
    {
        public int DataAtual { get; set; }

        public Calendario()
        {
            DataAtual = 0;
        }

        // Avança o tempo
        public void Avancar()
        {
            DataAtual += 1;
        }
    }
}
