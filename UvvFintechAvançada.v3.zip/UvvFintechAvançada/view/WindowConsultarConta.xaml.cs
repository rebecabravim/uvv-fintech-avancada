﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowConsultarConta.xaml
    /// </summary>
    public partial class WindowConsultarConta : Window
    {
        private Controle _controle;
        public WindowConsultarConta()
        {
            InitializeComponent();
            _controle = new Controle();
        }

        private void ConsultarCon_Click(object sender, RoutedEventArgs e)
        {
            string id = txtId.Text;

            if (string.IsNullOrWhiteSpace(id))
            {
                MessageBox.Show("Por favor, insira o Id da conta.");
                return;
            } else
            {
                var conta = _controle.ConsultarConta(id);
                if (conta != null)
                {
                    DataGridConta.ItemsSource = new List<Conta> { conta };
                }
                else
                {
                    MessageBox.Show("Conta não encontrada.");
                }
            }

            
        }
    }
}
