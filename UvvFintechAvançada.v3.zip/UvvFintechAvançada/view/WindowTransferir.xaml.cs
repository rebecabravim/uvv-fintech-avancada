﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowTransferir.xaml
    /// </summary>
    public partial class WindowTransferir : Window
    {
        private Controle _controle;
        public WindowTransferir()
        {
            InitializeComponent();
            _controle = new Controle();
        }

        private void Transferir_Click(object sender, RoutedEventArgs e)
        {
            string contaOrigemId = txtIdOrigem.Text;
            string contaDestinoId = txtIdDestino.Text;
            decimal valor;

            // 'decimal.TryParse(txtValor.Text, out valor)' tenta passar o valor do txtValor
            // para decimal, se houver sucesso retorna true e atribui o valor à variável 'valor'.

            // verifica se valor é válido
            if (decimal.TryParse(txtValor.Text, out valor) && valor > 0)
            {
                int status = _controle.Transferir(contaOrigemId, contaDestinoId, valor);

                //status 1 de sucesso
                if (status == 1)
                {
                    MessageBox.Show($"Saque de R${valor} realizado com sucesso!");
                }
                //status 2 para saldo insuficiente
                else if (status == 2)
                {
                    MessageBox.Show("Falha ao realizar o saque. Saldo suficiente.");
                    return;
                }
                //status 3 para Conta com Id não encontrada
                else if (status == 3)
                {
                    MessageBox.Show("Conta não encontrada. Verifique o Número da Conta.");
                    return;
                }
            } else
            {
                MessageBox.Show("Por favor, insira um valor válido para transferência.");
                return;
            }

        }
    }
}
