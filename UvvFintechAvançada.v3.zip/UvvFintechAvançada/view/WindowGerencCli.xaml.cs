﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowGerencCli.xaml
    /// </summary>
    public partial class WindowGerencCli : Window
    {
        public WindowGerencCli()
        {
            InitializeComponent();
        }

        private void AbrirWindowAdicionarCLi_Click(object sender, RoutedEventArgs e)
        {
            WindowAdicionarCliente windowAdicionarCliente = new WindowAdicionarCliente();
            windowAdicionarCliente.Show();
        }

        private void BtnRemoverCli_Click(object sender, RoutedEventArgs e)
        {
            WindowRemoverCliente windowRemoverCliente = new WindowRemoverCliente();
            windowRemoverCliente.Show();
        }

        private void AbrirConsultarCli_Click(object sender, RoutedEventArgs e)
        {
            WindowConsultarCliente windowConsultarCliente = new WindowConsultarCliente();
            windowConsultarCliente.Show();
        }
    }
}
