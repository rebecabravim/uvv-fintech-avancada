﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.bd;
using UvvFintechAvançada.control;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowAdicionarCon.xaml
    /// </summary>
    public partial class WindowAdicionarCon : Window
    {
        private Controle _controle;

        public WindowAdicionarCon()
        {
            InitializeComponent();
            _controle = new Controle();
        }

        private void AdicionarConta_Click(object sender, RoutedEventArgs e)
        {
            string idConta = txtId.Text.Trim();  
            decimal saldo;
            bool contaAdicionada = false;

            
            if (string.IsNullOrWhiteSpace(idConta))
            {
                MessageBox.Show("Por favor, insira um ID da conta.");
                return;
            } else if(Bd.RetornarContaBd(idConta) != null)
            {
                MessageBox.Show("Esse Id de conta já existe.");
                return;
            }

            if (!decimal.TryParse(txtSaldo.Text, out saldo))
            {
                MessageBox.Show("Por favor, insira um saldo válido.");
                return;
            }
            string cpfCliente = txtCliente.Text.Trim();

            string tipoConta = ((ComboBoxItem)comboTipoConta.SelectedItem).Content.ToString();

            if (tipoConta == "Selecione")
            {
                MessageBox.Show("Por favor, selecione o tipo de conta.");
                return;

            } else if (tipoConta == "Conta Corrente")
            {
                contaAdicionada = _controle.AdicionarConta(cpfCliente, idConta, saldo, tipoConta);
                if (contaAdicionada)
                {
                    MessageBox.Show("Conta adicionada com sucesso!");
                }
                else
                {
                    MessageBox.Show("Cliente não encontrado. Digite um CPF válido. A conta não pode ser adicionada.");
                    return;
                }
            }
            else if (tipoConta == "Conta Poupança")
            {
                contaAdicionada = _controle.AdicionarConta(cpfCliente, idConta, saldo, tipoConta);
                if (contaAdicionada)
                {
                    MessageBox.Show("Conta adicionada com sucesso!");
                }
                else
                {
                    MessageBox.Show("Cliente não encontrado. Digite um CPF válido. A conta não pode ser adicionada.");
                    return;
                }
            }

            
            txtId.Clear();
            txtSaldo.Clear();
            txtCliente.Clear();
        }
    }
}
