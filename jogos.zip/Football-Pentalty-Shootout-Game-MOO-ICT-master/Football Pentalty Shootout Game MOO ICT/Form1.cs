namespace Football_Pentalty_Shootout_Game_MOO_ICT
{
    // Made by MOO ICT
    // For educational purpose only
    public partial class Form1 : Form
    {

        List<string> KeeperPosition = new List<string> { "left", "right", "top", "topLeft", "topRight"};
        List<PictureBox> goalTarget;
        int ballX = 0;
        int ballY = 0;
        int goal = 0;
        int miss = 0;
        string state;
        string playerTarget;
        bool aimSet = false;
        Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            goalTarget = new List<PictureBox> { left, right, top, topLeft, topRight};
        }

        private void SetGoalTargetEvent(object sender, EventArgs e)
        {
            if (aimSet == true) { return; }

            BallTimer.Start();
            KeeperTimer.Start();
            ChangeGoalKeeperImage();    

            var senderObject = (PictureBox)sender;
            senderObject.BackColor = Color.Beige;

            if (senderObject.Tag.ToString() == "topRight")
            {
                ballX = -7;
                ballY = 15;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }
            if (senderObject.Tag.ToString() == "right")
            {
                ballX = -11;
                ballY = 15;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }
            if (senderObject.Tag.ToString() == "top")
            {
                ballX = 0;
                ballY = 20;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }
            if (senderObject.Tag.ToString() == "topLeft")
            {
                ballX = 8;
                ballY = 15;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }
            if (senderObject.Tag.ToString() == "left")
            {
                ballX = 7;
                ballY = 8;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }

            CheckScore();

        }

        private void KeeperTimerEvent(object sender, EventArgs e)
        {
            switch (state)
            {
                case "left":
                    goalKeeper.Left -= 6;
                    goalKeeper.Top = 204;
                    break;
                case "right":
                    goalKeeper.Left += 6;
                    goalKeeper.Top = 204;
                    break;
                case "top":
                    goalKeeper.Top -= 6;
                    break;
                case "topLeft":
                    goalKeeper.Left -= 6;
                    goalKeeper.Top -= 3;
                    break;
                case "topRight":
                    goalKeeper.Left += 6;
                    goalKeeper.Top -= 3;
                    break;
            }

            foreach (PictureBox x in goalTarget)
            {
                if (goalKeeper.Bounds.IntersectsWith(x.Bounds))
                {
                    KeeperTimer.Stop();
                    goalKeeper.Location = new Point(418, 169); // Volta para a posi��o inicial
                    goalKeeper.Image = Properties.Resources.stand_small; // Imagem padr�o do goleiro
                }
            }
        }

        private void BallTimerEvent(object sender, EventArgs e)
        {
            football.Left -= ballX;
            football.Top -= ballY;

            // Verifique se a bola saiu da tela
            if (football.Top < 0 || football.Left < 0 || football.Left > this.Width)
            {
                football.Location = new Point(430, 500); // Resetar a posi��o da bola
                ballX = 0;
                ballY = 0;
                aimSet = false;
                BallTimer.Stop();

                // Redefina o goleiro para a imagem padr�o ao sair da tela
                goalKeeper.Image = Properties.Resources.stand_small;
                return;
            }

            foreach (PictureBox x in goalTarget)
            {
                if (football.Bounds.IntersectsWith(x.Bounds))
                {
                    // Resetar a bola e parar o timer
                    football.Location = new Point(430, 500);
                    ballX = 0;
                    ballY = 0;
                    aimSet = false;
                    BallTimer.Stop();

                    // Redefina a imagem do goleiro ap�s um tiro
                    goalKeeper.Image = Properties.Resources.stand_small;
                    break; // Adicione um break aqui para sair do loop ap�s detectar a colis�o
                }
            }
        }


        private void CheckScore()
        {
            if (state != playerTarget) // Se o goleiro n�o defendeu
            {
                goal++;
                lblScore.Text = "Scored: " + goal;
            }
            else // Se o goleiro defendeu
            {
                miss++;
                lblMissed.Text = "Missed: " + miss;
            }
        }


        private void ChangeGoalKeeperImage()
        {
            KeeperTimer.Start();
            int i;

            // Definindo a l�gica para reduzir as op��es do goleiro ap�s certos gols
            if (goal >= 15)
            {
                // Se o jogador marcou 15 ou mais gols, o goleiro escolhe apenas entre 2 lados
                List<string> reducedPositions = new List<string> { playerTarget };
                while (reducedPositions.Count < 2)
                {
                    string randomPosition = KeeperPosition[random.Next(0, KeeperPosition.Count)];
                    if (!reducedPositions.Contains(randomPosition))
                    {
                        reducedPositions.Add(randomPosition);
                    }
                }
                i = random.Next(0, reducedPositions.Count);
                state = reducedPositions[i];
            }
            else if (goal >= 5)
            {
                // Se o jogador marcou 5 ou mais gols, o goleiro escolhe apenas entre 3 lados
                List<string> reducedPositions = new List<string> { playerTarget };
                while (reducedPositions.Count < 3)
                {
                    string randomPosition = KeeperPosition[random.Next(0, KeeperPosition.Count)];
                    if (!reducedPositions.Contains(randomPosition))
                    {
                        reducedPositions.Add(randomPosition);
                    }
                }
                i = random.Next(0, reducedPositions.Count);
                state = reducedPositions[i];
            }
            else
            {
                // Com menos de 5 gols, o goleiro escolhe entre todos os 5 lados
                i = random.Next(0, KeeperPosition.Count);
                state = KeeperPosition[i];
            }

            // Atualiza a imagem do goleiro com base na escolha
            switch (state)
            {
                case "left":
                    goalKeeper.Image = Properties.Resources.left_save_small;
                    break;
                case "right":
                    goalKeeper.Image = Properties.Resources.right_save_small;
                    break;
                case "top":
                    goalKeeper.Image = Properties.Resources.top_save_small;
                    break;
                case "topLeft":
                    goalKeeper.Image = Properties.Resources.top_left_save_small;
                    break;
                case "topRight":
                    goalKeeper.Image = Properties.Resources.top_right_save_small;
                    break;
            }
        }


    }
}