﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;

namespace UvvFintechAvançada.model
{
    internal class Depositar : ITransacao
    {
        public string Id { get; set; } = "";

        public bool RealizarDeposito(string contaId, decimal valor)
        {
            Conta? conta = Bd.RetornarContaBd(contaId);
            if (conta != null)
            {
                conta.Saldo += valor;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
