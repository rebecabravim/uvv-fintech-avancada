﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;

namespace UvvFintechAvançada.model
{
    internal class Sacar : ITransacao
    {
        public string Id { get; set; } = "";

        public int RealizarSaque(string contaId, decimal valor)
        {
            Conta? conta = Bd.RetornarContaBd(contaId);
            if (conta != null)
            {
                if (conta.Saldo >= valor)
                {
                    conta.Saldo -= valor;
                    //retorno para sucesso
                    return 1;
                }
                else
                {
                    //retorno para Saldo insuficiente
                    return 2;
                }
            }
            else
            {
                //retorno para Conta com Id não encontrada
                return 3;
            }
        }
    }
}
