﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UvvFintechAvançada.model
{
    class Cliente
    {
        public String Nome { get; set; } = "";
        public String Cpf { get; set; } = "";
        public String Endereco { get; set; } = "";

        public List<Conta> Contas { get; set; }

        public Cliente(string nome, string cpf, string endereco)
        {
            Nome = nome;
            Cpf = cpf;
            Endereco = endereco;
            Contas = new List<Conta>();
        }

        public void AdicionarContaParaCliente(Conta conta)
        {
            Contas.Add(conta);
        }
    }
}
