﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UvvFintechAvançada.model
{
    abstract class Conta
    {
        public String Id { get; set; } = "";
        public decimal Saldo { get; set; }
        public Cliente Cliente { get; set; }
        
        public String Tipo { get; set; } = "";

        public Conta(string id, decimal saldo, Cliente cliente, string tipo)
        {
            Id = id;
            Saldo = saldo;
            Cliente = cliente;
            Tipo = tipo;
        }



    }
}
