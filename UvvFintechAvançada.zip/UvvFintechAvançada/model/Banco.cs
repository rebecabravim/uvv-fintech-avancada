﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace UvvFintechAvançada.model
{
    class Banco
    {

        public Calendario calendario;
        public static GerenciadorDeContas gerenciadorDeContas = new();
        public static GerenciadorDeClientes gerenciadorDeClientes = new();
        public static GerenciadorDeTransacoes gerenciadorDeTransacoes = new();
        private static System.Timers.Timer timer;
        

        public Banco()
        {
            calendario = new Calendario();
            timer = new System.Timers.Timer(15000);
            timer.Elapsed += aumentarDias; // Evento que será chamado a cada 15 segundos
            timer.AutoReset = true; // Faz o timer repetir
            timer.Enabled = true;

        }

        private void aumentarDias(Object source, ElapsedEventArgs e)
        {
            calendario.Avancar(); // Chama o método para avançar o calendário
            gerenciadorDeContas.AtualizarContasPoupanca(calendario.DataAtual);
        }
    }
}
