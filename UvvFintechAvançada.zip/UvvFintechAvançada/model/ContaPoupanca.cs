﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UvvFintechAvançada.model
{
    internal class ContaPoupanca : Conta
    {
        public decimal Rendimentos {  get; set; }
        public decimal taxaRendimento = 0.01m;

        public ContaPoupanca(string id, decimal saldo, Cliente cliente, string tipo)
        : base(id, saldo, cliente, tipo)
        {
            Rendimentos = 0;
        }

        public void AtualizarRendimentos(int dias)
        {
            for (int i = 0; i < dias; i++)
            {
                // Calcula o rendimento diário
                decimal rendimentoDiario = Saldo * taxaRendimento;
                Rendimentos += rendimentoDiario; // Acumula os rendimentos
                Saldo += rendimentoDiario; // Adiciona os rendimentos ao saldo
            }
        }
    }
}
