﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using UvvFintechAvançada.bd;

namespace UvvFintechAvançada.model
{
    internal class GerenciadorDeContas
    {

        public bool AdicionarConta(string cpf, string idConta, decimal saldo, string tipo)
        {
            var cliente = Bd.RetornarClienteBd(cpf);
            //se o cliente existe
            if (cliente != null)
            {
                Conta novaConta;

                if (tipo == "Conta Corrente")
                {
                    novaConta = new ContaCorrente(idConta, saldo, cliente, tipo);
                }
                else
                {
                    novaConta = new ContaPoupanca(idConta, saldo, cliente, tipo);
                }


                cliente.AdicionarContaParaCliente(novaConta);
                Bd.SalvarContaBd(novaConta);
                return true; //retorno  de sucesso
            }
            else
            {
                return false; //retorno cliente não existe
            }
            
        }

        public void AtualizarContasPoupanca(int dias)
        {
            foreach (var conta in Bd.contas)
            {
                if (conta is ContaPoupanca contaPoupanca)
                {
                    contaPoupanca.AtualizarRendimentos(dias);
                }
            }
        }

        public bool RemoverConta(string id)
        {
            return Bd.RemoverContaBd(id);
        }

        public Conta? ConsultarConta(string id)
        {
            return Bd.RetornarContaBd(id);
        }
    }
}
