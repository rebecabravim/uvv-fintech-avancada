﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UvvFintechAvançada.model
{
    internal class ContaCorrente : Conta
    {
        public ContaCorrente(string id, decimal saldo, Cliente cliente, string tipo)
        : base(id, saldo, cliente, tipo)
        {
        }
    }
}
