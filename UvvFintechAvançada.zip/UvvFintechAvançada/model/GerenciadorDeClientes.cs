﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;

namespace UvvFintechAvançada.model
{
    internal class GerenciadorDeClientes
    {
        public bool AdicionarCliente(string nome, string cpf, string endereco)
        {
            // Verifica se o cliente com o mesmo CPF já existe
            if (Bd.RetornarClienteBd(cpf) != null)
            {
                // Se já existe, retorna falso indicando falha
                return false;
            }

            // Se não existe, cria um novo cliente e salva
            Cliente c = new Cliente(nome, cpf, endereco);
            Bd.SalvarClienteBd(c);
            return true; // sucesso
        }

        public bool RemoverCliente(string cpf)
        {
            return Bd.RemoverClienteBd(cpf);
        }

        public Cliente? ConsultarCliente(string cpf)
        {
            return Bd.RetornarClienteBd(cpf);
        }

    }
}
