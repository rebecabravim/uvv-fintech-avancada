﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UvvFintechAvançada.model
{
    internal interface ITransacao
    {
        public string Id { get; set; }
    }
}
