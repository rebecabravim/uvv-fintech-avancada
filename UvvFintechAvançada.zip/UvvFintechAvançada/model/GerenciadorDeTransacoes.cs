﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;

namespace UvvFintechAvançada.model
{
    internal class GerenciadorDeTransacoes
    {
        public int Sacar(string contaId, decimal valor)
        {
            Sacar saque = new Sacar(); 
            return saque.RealizarSaque(contaId, valor); 
        }

        public bool Depositar(string contaId, decimal valor)
        {
            Depositar deposito = new Depositar(); 
            return deposito.RealizarDeposito(contaId, valor);
        }

        public int Transferir(string contaOrigemId, string contaDestinoId, decimal valor)
        {
            Transferir transferencia = new Transferir(); 
            return transferencia.RealizarTransferencia(contaOrigemId, contaDestinoId, valor);
        }



    }
}
