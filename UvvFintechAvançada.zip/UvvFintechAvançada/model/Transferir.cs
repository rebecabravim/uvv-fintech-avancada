﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;

namespace UvvFintechAvançada.model
{
    internal class Transferir : ITransacao
    {
        public string Id { get; set; } = "";

        public int RealizarTransferencia(string contaOrigemId, string contaDestinoId, decimal valor) // Renomeado
        {
            Conta? contaOrigem = Bd.RetornarContaBd(contaOrigemId);
            Conta? contaDestino = Bd.RetornarContaBd(contaDestinoId);

            if (contaOrigem != null && contaDestino != null)
            {
                if (contaOrigem.Saldo >= valor)
                {
                    contaOrigem.Saldo -= valor;
                    contaDestino.Saldo += valor;
                    //retorno para sucesso
                    return 1;
                }
                else
                {
                    //retorno para Saldo insuficiente
                    return 2;
                }
            }
            else
            {
                //retorno para Conta com Id não encontrada
                return 3;
            }
        }
    }
}
