﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.bd
{
    internal class Bd
    {
        public static List<Cliente> clientes = new();
        public static List<Conta> contas = new();
        

        public static void SalvarClienteBd(Cliente cliente) => clientes.Add(cliente);
        public static Cliente? RetornarClienteBd(String Cpf) => clientes.Find(cliente => cliente.Cpf == Cpf);
        public static bool RemoverClienteBd(string cpf)
        {
            var cliente = RetornarClienteBd(cpf);
            if (cliente != null)
            {
                // Remove todas as contas associadas ao cliente
                foreach (var conta in cliente.Contas.ToList())
                {
                    RemoverContaBd(conta.Id);
                }

                clientes.Remove(cliente);
                return true;
            }
            return false;
        }

        public static void SalvarContaBd(Conta conta) => contas.Add(conta);
        public static Conta? RetornarContaBd(String id) => contas.Find(conta => conta.Id == id);
        public static bool RemoverContaBd(string id)
        {
            var conta = RetornarContaBd(id);
            if (conta != null)
            {
                contas.Remove(conta);
                return true;
            }
            return false;
        }


    }
}
