﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.control
{
    internal class ContasControl
    {

        public bool AdicionarConta(string cpf, string idConta, decimal saldo, string tipo)
        {
            return Banco.gerenciadorDeContas.AdicionarConta(cpf, idConta, saldo, tipo);
        }

        public bool RemoverConta(string id)
        {
            return Banco.gerenciadorDeContas.RemoverConta(id);
        }


        public Conta? ConsultarConta(string id)
        {
            return Banco.gerenciadorDeContas.ConsultarConta(id);
        }

    }
}
