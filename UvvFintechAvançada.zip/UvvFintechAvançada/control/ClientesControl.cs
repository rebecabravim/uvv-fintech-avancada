﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UvvFintechAvançada.bd;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.control
{
    internal class ClientesControl
    {

        public bool AdicionarCliente(string nome, string cpf, string endereco)
        {
            return Banco.gerenciadorDeClientes.AdicionarCliente(nome, cpf, endereco);
        }

        public bool RemoverCliente(string cpf)
        {
            return Banco.gerenciadorDeClientes.RemoverCliente(cpf);
        }

        public Cliente? ConsultarCliente(string cpf)
        {
            return Banco.gerenciadorDeClientes.ConsultarCliente(cpf);
        }
    }
}
