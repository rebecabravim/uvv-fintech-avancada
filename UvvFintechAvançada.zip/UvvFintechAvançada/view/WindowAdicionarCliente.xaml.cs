﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowAdicionarCliente.xaml
    /// </summary>
    public partial class WindowAdicionarCliente : Window
    {
        private ClientesControl _clientesControl;
        public WindowAdicionarCliente()
        {
            InitializeComponent();
            _clientesControl = new ClientesControl();
        }

        private void AdicionarCliente_Click(object sender, RoutedEventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string cpf = txtCpf.Text.Trim();
            string endereco = txtEndereco.Text.Trim();

            if (string.IsNullOrWhiteSpace(cpf))
            {
                MessageBox.Show("Por favor, insira o CPF do cliente.");
                return;
            } else
            {
                bool status = _clientesControl.AdicionarCliente(nome, cpf, endereco);
                if (!status)
                {
                    MessageBox.Show("Cliente já cadastrado com esse CPF.");
                    return;
                } else
                {
                    MessageBox.Show("Cliente adicionado com sucesso!");
                }

                
            }

            
            txtNome.Clear();
            txtCpf.Clear();
            txtEndereco.Clear();


        }
    }
}
