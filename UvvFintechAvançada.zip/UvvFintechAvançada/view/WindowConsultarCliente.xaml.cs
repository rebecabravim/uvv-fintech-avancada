﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowConsultarCliente.xaml
    /// </summary>
    public partial class WindowConsultarCliente : Window
    {
        private ClientesControl _clientesControl;
        public WindowConsultarCliente()
        {
            InitializeComponent();
            _clientesControl = new ClientesControl();
        }

        private void ConsultarCli_Click(object sender, RoutedEventArgs e)
        {
            string cpf = txtCpf.Text.Trim();
            if (string.IsNullOrWhiteSpace(cpf))
            {
                MessageBox.Show("Por favor, insira o CPF do cliente.");
                return;
            } else
            {
                var cliente = _clientesControl.ConsultarCliente(cpf);

                if (cliente != null)
                {
                    DataGridCliente.ItemsSource = new List<Cliente> { cliente };
                }
                else
                {
                    MessageBox.Show("Cliente não encontrado.");
                }
            }
            
        }
    }
}
