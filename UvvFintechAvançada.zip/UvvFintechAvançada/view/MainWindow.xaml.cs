﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.bd;
using UvvFintechAvançada.model;
using UvvFintechAvançada.view;



namespace UvvFintechAvançada
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AbrirWindowGerencCli_Click(object sender, RoutedEventArgs e)
        {
            WindowGerencCli windowGerencCli = new();
            windowGerencCli.Show();

            //this.Visibility = Visibility.Hidden;
        }

        private void AbrirWindowGerencCon_Click(object sender, RoutedEventArgs e)
        {
            WindowGerencCon windowGerencCon = new();
            windowGerencCon.Show();
        }

        private void AbrirWindowGerencTra_Click(object sender, RoutedEventArgs e)
        {
            WindowGerencTra windowGerencTra = new();
            windowGerencTra.Show();
        }
    }
}