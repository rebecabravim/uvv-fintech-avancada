﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowRemoverCliente.xaml
    /// </summary>
    public partial class WindowRemoverCliente : Window
    {
        private ClientesControl _clientesControl;
        public WindowRemoverCliente()
        {
            InitializeComponent();
            _clientesControl = new ClientesControl();
        }

        private void RemoverCli_Click(object sender, RoutedEventArgs e)
        {
            string cpf = txtCpf.Text;
            if (!string.IsNullOrWhiteSpace(cpf))
            {
                bool status = _clientesControl.RemoverCliente(cpf);
                if (status)
                {
                    MessageBox.Show($"Cliente e suas contas foram removidos com sucesso!");
                }
                else
                {
                    MessageBox.Show($"Cliente com CPF não encontrado.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um CPF válido.");
            }
        }
    }
}
