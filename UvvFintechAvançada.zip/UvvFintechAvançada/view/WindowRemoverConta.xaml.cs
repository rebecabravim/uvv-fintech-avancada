﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowRemoverConta.xaml
    /// </summary>
    public partial class WindowRemoverConta : Window
    {
        private ContasControl _contasControl;
        public WindowRemoverConta()
        {
            InitializeComponent();
            _contasControl = new ContasControl();
        }

        private void RemoverCon_Click(object sender, RoutedEventArgs e)
        {
            string contaId = txtId.Text;

            if (!string.IsNullOrWhiteSpace(contaId))
            {
                var resultado = _contasControl.RemoverConta(contaId);

                if (resultado)
                {
                    MessageBox.Show($"Conta removida com sucesso!");
                }
                else
                {
                    MessageBox.Show($"Conta com Id  não encontrada.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um Id de conta válido.");
            }
        }
    }
}
