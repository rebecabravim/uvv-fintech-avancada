﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowDepositar.xaml
    /// </summary>
    public partial class WindowDepositar : Window
    {

        public WindowDepositar()
        {
            InitializeComponent();
        }

        private void Depositar_Click(object sender, RoutedEventArgs e)
        {
            string contaId = txtId.Text;
            decimal valor;

            // 'decimal.TryParse(txtValor.Text, out valor)' tenta passar o valor do txtValor
            // para decimal, se houver sucesso retorna true e atribui o valor à variável 'valor'.

            // verifica se valor é válido
            if (decimal.TryParse(txtValor.Text, out valor) && valor > 0)
            {
                bool status = Banco.gerenciadorDeTransacoes.Depositar(contaId, valor);
                if (status)
                {
                    MessageBox.Show($"Depósito de R${valor} realizado com sucesso!");
                } else
                {
                    MessageBox.Show("Conta não encontrada. Verifique o Número da Conta.");
                    return;
                }
            } else
            {
                MessageBox.Show("Por favor, insira um valor válido para depósito.");
                return;
            }

        }
    }
}
