﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowGerencTra.xaml
    /// </summary>
    public partial class WindowGerencTra : Window
    {
        public WindowGerencTra()
        {
            InitializeComponent();

        }

        private void AbrirWindowSacar_Click(object sender, RoutedEventArgs e)
        {
            WindowSacar windowSacar = new WindowSacar();
            windowSacar.Show();
        }

        private void AbrirWindowDepositar_Click(object sender, RoutedEventArgs e)
        {
            WindowDepositar windowDepositar = new WindowDepositar();
            windowDepositar.Show();
        }

        private void AbrirWindowTransferir_Click(object sender, RoutedEventArgs e)
        {
            WindowTransferir windowTransferir = new WindowTransferir();
                windowTransferir.Show();
        }
    }
}
