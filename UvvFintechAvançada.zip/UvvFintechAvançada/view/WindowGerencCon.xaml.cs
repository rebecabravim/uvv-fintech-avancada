﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UvvFintechAvançada.control;
using UvvFintechAvançada.model;

namespace UvvFintechAvançada.view
{
    /// <summary>
    /// Lógica interna para WindowGerencCon.xaml
    /// </summary>
    public partial class WindowGerencCon : Window
    {
        public WindowGerencCon()
        {
            InitializeComponent();
        }

        private void AbrirAdicionarCont_Click(object sender, RoutedEventArgs e)
        {
            WindowAdicionarCon windowAdicionarCon = new WindowAdicionarCon();
            windowAdicionarCon.Show();
        }

        private void AbrirRemoverCon_Click(object sender, RoutedEventArgs e)
        {
            WindowRemoverConta windowRemoverConta = new WindowRemoverConta();
            windowRemoverConta.Show();
        }

        private void AbrirConsultarCon_Click(object sender, RoutedEventArgs e)
        {
            WindowConsultarConta windowConsultarConta = new WindowConsultarConta();
            windowConsultarConta.Show();
        }

        
    }
}
